#ifndef AIRPORT_H
#define AIRPORT_H

class Airport
{
public:
    char    code[5];
    double   longitude;
    double   latitude;
    double  distance;  // from reference point

};

#endif
